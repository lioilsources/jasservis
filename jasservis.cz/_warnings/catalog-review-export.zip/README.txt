J&S SERVIS — independent content review, preview only.
Incomplete catalogue; scope is per model, edition and equipment.
Semantic records, model assignments, colour variants and distinct shapes are different counts.
All CZ/EN/DE texts are in catalog-texts.*.csv and locales.json. Source/edition/page data are in catalog.json and review registers. Shared symbol files appear once, with credits and licences in used-symbols.csv.
No full owner manuals, private SSPs, user photographs or manufacturer source artwork included. Standard licensed depictions are not OEM facsimiles. Missing or unclear symbols are not replaced with approximate icons.
The archive also includes coverage.csv, manual-review.csv, the three work-queues CSVs, verification.json and export-manifest.json with per-file SHA-256 hashes. Technical tests are not content verification. Received, overlapping and missing photo groups are explicitly separated in attachment-groups.json; row-level Enyaq, Multivan and, when available, unknown-model Audi photo comparisons are included without the photographs themselves.
